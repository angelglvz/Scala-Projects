import scala.swing._
import scala.swing.event._
import java.awt.event._

object main extends SimpleSwingApplication{
  def top: MainFrame = new MainFrame{
    title = "String Application"
    contents = new BoxPanel(Orientation.Vertical) {
      border = Swing.EmptyBorder(30,30,30,30)
      contents += Swing.VStrut(5)
      contents += new TextField() {

        background = new Color(0xddffdd);
        border = Swing.EtchedBorder
        focusable = false
      }
      contents += Swing.VStrut(5)
      contents += Swing.Glue
      contents += new GridPanel(2,2) {
        for ( c <- "1234" )
          contents += new Button(c.toString) { Mediator.buttons += this }
      }
    }
    Mediator.programInteractions()
  }
}
object Mediator extends Reactor {
  var panel:TextComponent = null
  var buttons = Set[Button]()
  // wires interactions
  def programInteractions() {
    buttons.foreach(listenTo(_))


    reactions += { case ButtonClicked(b) if "1234".contains(b.text) => {
      panel.text += b.text }
    }
  }
}
object opstack {
  var nstack = List[Double]()
  var op = ""
  def addNumber(s:Double) {
    nstack.length match {
      case x if nstack.length < 2 => nstack = s :: nstack
      case _ => {reset(); nstack = s :: nstack}
    }
  }
  def result() = {
    val (arg1, arg2) = (nstack.tail.head, nstack.head)
    val res = op match {
      case "+" => arg1+arg2
      case "-" => arg1-arg2
      case "*" => arg2*arg1
      case "/" => arg1/arg2
    }
    reset()
    addNumber(res) // cummulate the result
    res
  }
  def reset() { nstack = List[Double]() }
}

